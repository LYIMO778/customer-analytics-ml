# Customer Analytics — Starter

A small, original practice project demonstrating data cleaning and descriptive analysis using **synthetic sample data**.

## What it does
- Removes duplicate customer IDs.
- Imputes missing ages with the median when possible.
- Compares observed average spending between customers who did and did not receive emails.

**Important:** This comparison is descriptive; it does **not** establish that emails caused increased spending. The sample is synthetic and tiny, and is not suitable for real business inference.

## Run (Windows PowerShell)
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m src.analysis
python -m pytest -q
```

## Next steps
- Add a larger documented dataset and exploratory plots.
- Create a proper randomized A/B test analysis or an ML training pipeline with leakage-safe splits.
- Explain assumptions, limitations, and evaluation metrics.
