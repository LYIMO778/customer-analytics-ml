import pandas as pd
from src.analysis import clean_customers, average_spending_by_group


def test_clean_customers_removes_duplicate_ids_and_fills_age():
    df = pd.DataFrame({'customer_id': [1, 1, 2], 'age': [20, 20, None]})
    result = clean_customers(df)
    assert len(result) == 2
    assert result['age'].isna().sum() == 0


def test_average_spending():
    df = pd.DataFrame({'received_email': [True, True, False], 'spending': [10, 30, 5]})
    result = average_spending_by_group(df)
    assert result[True] == 20
    assert result[False] == 5
