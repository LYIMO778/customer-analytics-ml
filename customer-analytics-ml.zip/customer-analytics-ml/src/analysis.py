import pandas as pd


def clean_customers(df: pd.DataFrame) -> pd.DataFrame:
    """Remove duplicate customer IDs and fill missing age with median."""
    result = df.drop_duplicates(subset=['customer_id']).copy()
    result['age'] = pd.to_numeric(result['age'], errors='coerce')
    if result['age'].notna().any():
        result['age'] = result['age'].fillna(result['age'].median())
    return result


def average_spending_by_group(df: pd.DataFrame) -> pd.Series:
    """Summarize observed spending, not causal effects."""
    return df.groupby('received_email')['spending'].mean()


if __name__ == '__main__':
    customers = pd.read_csv('data/customers.csv')
    cleaned = clean_customers(customers)
    print(average_spending_by_group(cleaned))
